# FEUP-IART

## Metaheuristics for Optimization Problem

The program solves an Optimization problem using Metaheuristics algorithms, specifically Genetic algorithm and Simulated Annealing algorithm.

## Introduction

The program was developed as a part of Artificial Intelligence course at FEUP, University of Porto. The given problem is an Optimization problem, a simplified problem of a real Optimal Inspection Routes Problem for ASAE - Portuguese Economic and Food Safety Authority, a specialized authority responsible for food safety and economic surveillance in Portugal.

## Description

The problem is a type of Vehicle Routing Problem where inspection brigades must start and end their routes at a Depot, conduct a certain number of inspections, and align with establishments' schedules. The goal is to optimize routing to minimize distance traveled while satisfying all constraints, including a 9:00 AM departure time for all routes.

Two scenarios of the problem were eximined:

a) Travel time minimization 

b) Resource allocation minimization

learn more in the report and presentation.

## Installation

open AITSP.ipynb file using [google colab](https://colab.research.google.com/) or [Jupyter](https://jupyter.org/install). Run the first slot which is responsible for importing data. By default the data is imported from google drive cloud. It is possible to import the data locally, from pc. 

If you wish to import the data locally from your PC, skip the first cell. Locate the data.xslx path and run the second cell.
If you wish to import the data from google drive cloud, run the first cell and skip the second cell (preferred for google colab).
## Usage

Run the code and follow the instructions in the comments

## Contact

If you have any problems, questions, ideas or suggestions, please contact us via email.

André Oliveira Araújo Dias up201904568@fe.up.pt

David Burchakov up202203777@edu.fe.up.pt
